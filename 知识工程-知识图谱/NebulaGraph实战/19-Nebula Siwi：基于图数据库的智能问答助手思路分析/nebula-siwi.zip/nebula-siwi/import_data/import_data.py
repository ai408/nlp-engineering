import time

from nebula3.gclient.net import ConnectionPool
from nebula3.Config import Config


def execute_ngql_from_file(file_path, host, port, user, password):
    # 创建连接池
    config = Config()
    config.max_connection_pool_size = 10
    connection_pool = ConnectionPool()
    if not connection_pool.init([(host, port)], config):
        print("Failed to init connection pool")
        return

    # 获取会话
    session = connection_pool.get_session(user, password)

    # 读取并执行NGQL文件
    count = 0
    with open(file_path, 'r') as file:
        ngql_statements = file.read().split(';')
        ngql_statements = [i.strip() for i in ngql_statements]
        for statement in ngql_statements:
            if statement:
                # print(statement)
                resp = session.execute(statement)
                if resp.is_succeeded():
                    print(f"Successfully executed statement: {statement}")
                else:
                    print(f"Failed to execute statement: {statement}. Error: {resp.error_msg()}")

                count += 1
                if(count == 2):  # 第2条语句执行完后休眠20s
                    time.sleep(20)
                if (count == 7):  # 第7条语句执行完后休眠20s
                    time.sleep(20)
                if (count == 9):  # 第9条语句执行完后休眠20s
                    time.sleep(20)

    # 释放会话
    session.release()


if __name__ == '__main__':
    # 使用你的Nebula Graph的主机、端口、用户名和密码
    execute_ngql_from_file('basketballplayer-2.X_v1_更新文件.ngql', '172.25.175.251', 9669, 'root', 'nebula')