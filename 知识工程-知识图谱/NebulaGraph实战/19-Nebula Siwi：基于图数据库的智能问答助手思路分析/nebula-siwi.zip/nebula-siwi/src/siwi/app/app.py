from siwi import app

application = app = app.app