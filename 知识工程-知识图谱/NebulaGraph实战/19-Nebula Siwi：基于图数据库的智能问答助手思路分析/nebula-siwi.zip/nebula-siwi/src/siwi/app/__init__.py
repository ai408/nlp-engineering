import os

from flask import Flask, jsonify, request
from nebula3.gclient.net import ConnectionPool
from nebula3.Config import Config

from siwi.bot import bot


app = Flask(__name__)


@app.route("/")
def root():
    return "Hey There?"


@app.route("/query", methods=["POST"])
def query():
    request_data = request.get_json()
    question = request_data.get("question", "")
    if question:
        answer = siwi_bot.query(request_data.get("question", ""))
    else:
        answer = "Sorry, what did you say?"
    return jsonify({"answer": answer})


def parse_nebula_graphd_endpoint():
    ng_endpoints_str = os.environ.get('NG_ENDPOINTS', '127.0.0.1:9669,').split(",")  # 环境变量NG_ENDPOINTS
    ng_endpoints = []
    for endpoint in ng_endpoints_str:
        if endpoint:
            parts = endpoint.split(":")  # we dont consider IPv6 now
            ng_endpoints.append((parts[0], int(parts[1])))  # (ip, port)
    return ng_endpoints  # [(ip, port), (ip, port), ...]


ng_config = Config()  # NebulaGraph配置
ng_config.max_connection_pool_size = int(os.environ.get('NG_MAX_CONN_POOL_SIZE', 10))  # 环境变量NG_MAX_CONN_POOL_SIZE
ng_endpoints = parse_nebula_graphd_endpoint()  # [(ip, port), (ip, port), ...]
connection_pool = ConnectionPool()  # 连接池

def main():
    connection_pool.init(ng_endpoints, ng_config)  # 初始化连接池


if __name__ == "__main__":
    main()
    siwi_bot = bot.SiwiBot(connection_pool)  # 初始化机器人

    try:
        app.run(host="0.0.0.0", port=5000)  # 启动Flask
    finally:
        connection_pool.close()
else:
    main()
