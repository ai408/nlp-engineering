import importlib
import siwi
import yaml


class SiwiActions():
    def __init__(self) -> None:
        self.intent_map = {}  #
        self.load_data()

    def load_data(self) -> None:
        # 从yaml文件中加载数据
        module_path = f"{ siwi.__path__[0] }/bot/test/data"

        with open(f"{ module_path }/example_intents.yaml", "r") as file:
            self.intent_map = yaml.safe_load(file)["intents"]

    def get(self, intent: dict):
        """
        returns SiwiActionBase
        """
        # 如果没有识别到意图（relationship、serve和friend），就返回fallback意图
        if len(intent["intents"]) > 0:
            intent_name = intent["intents"][0]
        else:
            intent_name = "fallback"

        cls_name = self.intent_map.get(intent_name).get("action")  # 获取意图对应的action类名，比如RelationshipAction
        action_cls = getattr(  # action_cls类型为<class 'siwi.bot.actions.RelationshipAction'>
            importlib.import_module("siwi.bot.actions"), cls_name)  # 通过类名获取类
        action = action_cls(intent)  # 使用intent来初始化action类
        return action


class SiwiActionBase():
    def __init__(self, intent: dict):
        """
        intent:
        {
            "entities": entities,
            "intents": intents
        }
        """
        self.load_test_data()
        self.error = False

    def load_test_data(self) -> None:
        module_path = f"{ siwi.__path__[0] }/bot/test/data"

        with open(f"{ module_path }/example_players.yaml", "r") as file:
            self.players = yaml.safe_load(file)  # 加载球员数据

        with open(f"{ module_path }/example_teams.yaml", "r") as file:
            self.teams = yaml.safe_load(file)  # 加载球队数据

        self.player_names = {
            value: key for (key, value) in self.players.items()
            }  # 将球员数据的key和value互换
        self.team_names = {
            value: key for (key, value) in self.teams.items()
            }  # 将球队数据的key和value互换

    def _name(self, vid: str) -> str:
        if vid.startswith("player"):  # 如果vid以player开头，就返回球员名字
            return self.player_names.get(vid, "unknown player")
        elif vid.startswith("team"):  # 如果vid以team开头，就返回球队名字
            return self.team_names.get(vid, "unkonwn team")
        else:  # 否则返回unknown
            return "unkonwn"

    def _vid(self, name: str) -> str:
        if name in self.players:  # 如果name在球员数据中，就返回球员id
            return self.players[name]
        elif name in self.teams:  # 如果name在球队数据中，就返回球队id
            return self.teams[name]
        else:  # 否则抛出异常
            print(
                f"[ERROR] Something went wrong, unknown vertex name { name }")
            raise

    def _error_check(self):
        if self.error:  # 如果error为True，就抛出异常
            return "Opps, something went wrong."


class FallbackAction(SiwiActionBase):
    def __init__(self, intent):
        super().__init__(intent)  # 使用intent初始化SiwiActionBase

    def execute(self, connection_pool=None):
        """
        TBD: query some information via nbi_api in fallback case:
        https://github.com/swar/nba_api/blob/master/docs/examples/Basics.ipynb
        """
        return """
Sorry I don't understand your questions for now. Here are supported question patterns:  
# 对不起，我现在还不明白你的问题。以下是支持的问题模式：

relation:  # 关系
    - What is the relationship between Yao Ming and Lakers?  # 姚明和湖人的关系是什么？
    - How does Yao Ming and Lakers connected?  # 姚明和湖人是怎么连接的？
serving:  # 服务
    - Which team had Yao Ming served?  # 姚明曾经效力过哪些球队？
friendship:  # 友谊
    - Whom does Tim Duncan follow?  # 邓肯关注了哪些人？
    - Who are Yao Ming's friends?  # 姚明的朋友有哪些？
"""


class RelationshipAction(SiwiActionBase):
    """
    USE basketballplayers;
    FIND NOLOOP PATH
    FROM "player100" TO "team204" OVER * BIDIRECT UPTO 4 STEPS YIELD path AS p;
    """
    def __init__(self, intent):
        print(f"[DEBUG] RelationshipAction intent: { intent }")
        super().__init__(intent)
        try:
            self.entity_left, self.entity_right = intent["entities"]  # 获取entities信息，比如Yao Ming和Lakers
            self.left_vid = self._vid(self.entity_left)  # 获取球员的id
            self.right_vid = self._vid(self.entity_right)  # 获取球队的id
        except Exception:  # 如果获取失败，就抛出异常
            print(
                f"[WARN] RelationshipAction entities recognition Failure "
                f"will fallback to FallbackAction, "
                f"intent: { intent }"
                )
            self.error = True  # 设置error为True

    def execute(self, connection_pool) -> str:
        self._error_check()  # 检查error
        query = (  # 查询语句，查找两个实体之间的关系
            f'USE basketballplayers;'
            f'FIND NOLOOP PATH '
            f'FROM "{self.left_vid}" TO "{self.right_vid}" '
            f'OVER * BIDIRECT UPTO 4 STEPS YIELD path AS p;'
            )
        print(  # 打印查询语句
            f"[DEBUG] query for RelationshipAction :\n\t{ query }"
            )
        with connection_pool.session_context("root", "nebula") as session:
            result = session.execute(query)

        if not result.is_succeeded():
            return (  # 如果查询失败，就返回错误信息
                f"Something is wrong on Graph Database connection when query "
                f"{ query }"
                )

        if result.is_empty():
            return (  # 如果查询结果为空，就返回没有关系的信息
                f"There is no relationship between "
                f"{ self.entity_left } and { self.entity_right }"
                )
        path = result.row_values(0)[0].as_path()  # 获取查询结果的第一行，即关系路径
        relationships = path.relationships()  # 获取关系
        relations_str = self._name(relationships[0].start_vertex_id().as_string())  # 获取关系的起始点
        for rel_index in range(path.length()):  # 遍历关系
            rel = relationships[rel_index]  # 获取关系
            relations_str += (  # 拼接关系信息
                f" { rel.edge_name() }s "
                f"{ self._name(rel.end_vertex_id().as_string()) }")
        return (  # 返回关系信息
            f"There are at least { result.row_size() } relations between "
            f"{ self.entity_left } and { self.entity_right }, "
            f"one relation path is: { relations_str }."
            )


class ServeAction(SiwiActionBase):
    """
    USE basketballplayers;
    MATCH p=(v)-[e:serve*1]->(v1)
    WHERE id(v) == "player133"
         RETURN p LIMIT 100
    """
    def __init__(self, intent):
        print(f"[DEBUG] ServeAction intent: { intent }")
        super().__init__(intent)
        try:
            self.player0 = list(intent["entities"].keys())[0]
            self.player0_vid = self._vid(self.player0)
        except Exception:
            print(
                f"[WARN] ServeAction entities recognition Failure "
                f"will fallback to FallbackAction, "
                f"intent: { intent }"
                )
            self.error = True

    def execute(self, connection_pool) -> str:
        self._error_check()
        query = (
            f'USE basketballplayers;'
            f'MATCH p=(v)-[e:serve*1]->(v1) '
            f'WHERE id(v) == "{ self.player0_vid }" '
            f'    RETURN p LIMIT 100;'
            )
        print(
            f"[DEBUG] query for RelationshipAction :\n\t{ query }"
            )
        with connection_pool.session_context("root", "nebula") as session:
            result = session.execute(query)

        if not result.is_succeeded():
            return (
                f"Something is wrong on Graph Database connection when query "
                f"{ query }"
                )

        if result.is_empty():
            return (
                f"There is no teams served by "
                f"{ self.player0 }"
                )
        serving_teams_str = ""
        for index in range(result.row_size()):
            rel = result.row_values(index)[0].as_path().relationships()[0]
            serving_teams_str += (
                f"{ self._name(rel.end_vertex_id().as_string()) } "
                f"from { rel.properties()['start_year'] } "
                f"to { rel.properties()['start_year'] }; "
                )
        return (
            f"{ self.player0 } had served { result.row_size() } team"
            f"{'s' if result.row_size() > 1 else ''}. "
            f"{ serving_teams_str }"
            )


class FollowAction(SiwiActionBase):
    """
    USE basketballplayers;
    MATCH p=(v)-[e:follow*1]->(v1)
    WHERE id(v) == "player133"
         RETURN p LIMIT 100
    """
    def __init__(self, intent):
        print(f"[DEBUG] FollowAction intent: { intent }")
        super().__init__(intent)
        try:
            self.player0 = list(intent["entities"].keys())[0]
            self.player0_vid = self._vid(self.player0)
        except Exception:
            print(
                f"[WARN] ServeAction entities recognition Failure "
                f"will fallback to FallbackAction, "
                f"intent: { intent }"
                )
            self.error = True

    def execute(self, connection_pool) -> str:
        self._error_check()
        query = (
            f'USE basketballplayers;'
            f'MATCH p=(v)-[e:follow*1]->(v1) '
            f'WHERE id(v) == "{ self.player0_vid }" '
            f'    RETURN p LIMIT 100;'
            )
        print(
            f"[DEBUG] query for RelationshipAction :\n\t{ query }"
            )
        with connection_pool.session_context("root", "nebula") as session:
            result = session.execute(query)

        if not result.is_succeeded():
            return (
                f"Something is wrong on Graph Database connection when query "
                f"{ query }"
                )

        if result.is_empty():
            return (
                f"There is no players followed by "
                f"{ self.player0 }"
                )
        following_players_str = ""
        for index in range(result.row_size()):
            rel = result.row_values(index)[0].as_path().relationships()[0]
            following_players_str += (
                f"{ self._name(rel.end_vertex_id().as_string()) } "
                f"in degree { rel.properties()['degree'] }; "
                )
        return (
            f"{ self.player0 } had followed { result.row_size() } player"
            f"{'s' if result.row_size() > 1 else ''}. "
            f"{ following_players_str }"
            )


if __name__ == '__main__':
    from siwi.app import main, connection_pool
    main()

    # 测试relationship意图
    # actions = SiwiActions()
    # intent_entities = {
    #     "entities": {
    #         "Yao Ming": "player133",
    #         "Rockets": "team202"
    #     },
    #     "intents": ["relationship"]
    # }
    # action = actions.get(intent_entities)
    # print(action.execute(connection_pool))


    actions = SiwiActions()
    intent_entities = {
        "entities": {
            "Yao Ming": "player133",
            "Rockets": "team202"
        },
        "intents": ["relationship"]
    }
    action = actions.get(intent_entities)
    print(action.execute(connection_pool))