import ahocorasick
import siwi
import yaml


class SiwiClassifier():
    def __init__(self) -> None:
        self.players = {}  # 球员
        self.teams = {}  # 球队
        self.entity_type_map = {}  # 实体类型映射
        self.intents_map = {}  # 意图映射
        self.setup_data()  # 加载数据

    def setup_data(self) -> None:
        self.load_entity_data()  # 加载实体数据
        self.setup_entity_tree()  # 构建实体树
        self.setup_intents_map()  # 构建意图映射

    def load_entity_data(self) -> None:
        # 从yaml文件中加载数据
        module_path = f"{ siwi.__path__[0] }/bot/test/data"  # 模块路径

        with open(f"{ module_path }/example_players.yaml", "r") as file:  # 球员
            self.players = yaml.safe_load(file)

        with open(f"{ module_path }/example_teams.yaml", "r") as file:  # 球队
            self.teams = yaml.safe_load(file)

        with open(f"{ module_path }/example_intents.yaml", "r") as file:  # 意图
            self.intents = yaml.safe_load(file)["intents"]

    def setup_entity_tree(self) -> None:  # 构建实体树
        self.entity_type_map.update({  # 实体类型映射，球员
            key: "player" for key in self.players.keys()
            })
        self.entity_type_map.update({  # 实体类型映射，球队
            key: "team" for key in self.teams.keys()
            })

        self.entity_tree = ahocorasick.Automaton()  # 构建实体树，自动机
        for index, entity in enumerate(self.entity_type_map.keys()):  # 遍历实体类型映射
            self.entity_tree.add_word(entity, (index, entity))  # 添加实体
        self.entity_tree.make_automaton()  # 构建自动机

    def setup_intents_map(self) -> None:  # 构建意图映射
        for name, intent in self.intents.items():  # 遍历意图
            self.intents_map.update({  # 意图映射
                keyword: name for keyword in intent['keywords']
                })

    def get_matched_entities(self, sentence: str) -> dict:
        """
        Consume a sentence to be matched with ahocorasick
        Returns a dict: {entity: entity_type}
        """
        # 中文翻译
        """
        消耗一个句子与ahocorasick匹配
        返回一个dict：{entity: entity_type}
        """
        entities_matched = []
        for item in self.entity_tree.iter(sentence):
            entities_matched.append(item[1][1])
        return {
            entity: self.entity_type_map[entity] for entity in entities_matched
            }

    def get_matched_intents(self, sentence: str) -> tuple:
        """
        消耗一个句子与intent匹配
        """

        intents_matched = set()
        for word in self.intents_map.keys():
            if word in sentence:
                intents_matched.add(
                    self.intents_map[word])
        return tuple(intents_matched)

    def get(self, sentence: str) -> dict:
        """
        Classify Sentences and Fill Slots.
        This should be done by NLP, here we fake one to demostrate
        the intent Actor --> Graph DB work flow.

        sentense:
        relation:
            - What is the relationship between Yao Ming and Lakers?
            - How does Tracy McGrady and Lakers connected?
        serving:
            - Which team had Jonathon Simmons served?
        friendship:
            - Whom does Tim Duncan follow?
            - Who are Tracy McGrady's friends?

        returns:
        {
            "entities": entities,
            "intents": intents
        }
        """
        # 中文翻译
        """
        句子分类和插槽填充。
        这应该由NLP完成，这里我们伪造一个来演示。
        意图Actor --> Graph DB工作流程。
        
        sentense:
        relation:(payer和team之间的关系)
            - 姚明和湖人之间的关系是什么？
            - 麦迪和湖人是如何连接的？
        serving:(payer和team之间的关系)
            - 乔纳森·西蒙斯为哪支球队效力？
        friendship:(team和team之间的关系)
            - 蒂姆·邓肯关注谁？
            - 谁是麦迪的朋友？
        
        returns:
        {
            "entities": entities,
            "intents": intents
        }
        """

        entities = self.get_matched_entities(sentence)
        intents = self.get_matched_intents(sentence)
        return {
            "entities": entities,
            "intents": intents
        }


if __name__ == "__main__":
    classifier = SiwiClassifier()
    sentence = "What is the relationship between Yao Ming and Lakers?"

    print(classifier.get(sentence))
    # 输出结果如下所示：
    # {'entities': {'Yao Ming': 'player', 'Lakers': 'team'}, 'intents': ('relationship',)}