from siwi.bot.actions import SiwiActions
from siwi.bot.classifier import SiwiClassifier


class SiwiBot():
    def __init__(self, connection_pool) -> None:
        self.classifier = SiwiClassifier()  # 分类器
        self.actions = SiwiActions()  # 动作
        self.connection_pool = connection_pool  # 连接池

    def query(self, sentence):
        intent = self.classifier.get(sentence)  # 获取意图
        action = self.actions.get(intent)  # 获取动作
        return action.execute(self.connection_pool)  # 执行动作
